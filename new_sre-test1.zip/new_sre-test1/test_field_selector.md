# 患者資料欄位選擇器測試說明

## 功能概述
新增了一個患者資料欄位選擇器，允許用戶選擇要從 Patient JSON 回應中提取的特定項目，並將其放入 LLM 提示中。

## 新增功能

### 1. 後端 API 變更
- **新增端點**: `GET /api/chat/patient-fields`
  - 返回可用的患者資料欄位列表
  - 包含欄位路徑、顯示名稱、類型和描述

- **修改端點**: `POST /api/chat/`
  - 新增 `selectedFields` 參數
  - 根據選擇的欄位過濾患者資料

### 2. 前端介面變更
- **新增按鈕**: "📋 選擇資料欄位" 按鈕
- **新增面板**: 欄位選擇器面板，包含：
  - 全選/清除按鈕
  - 可滾動的欄位列表
  - 每個欄位顯示名稱、類型和描述

### 3. 可用欄位
- `hkgiID`: HKGI 識別碼
- `pcID`: PC 識別碼  
- `birthDate`: 出生日期
- `sex`: 性別
- `referDepartment`: 轉介部門
- `referDivision`: 轉介分科
- `smokingStatus`: 吸煙狀況
- `alcoholFrequency`: 飲酒頻率
- `hpoTerm`: HPO 術語列表
- `clinicalSummary`: 臨床摘要
- `clinicalNote`: 臨床記錄列表
- `investigationTest`: 檢查項目列表
- `investigationTestNote`: 檢查記錄列表
- `specimen`: 檢體列表

## 使用方法

### 1. 啟動服務
```bash
# 啟動主 API 服務器
go run main.go

# 啟動聊天服務器
cd chat_server
go run main.go
```

### 2. 使用介面
1. 打開瀏覽器訪問 `http://localhost:8081`
2. 輸入認證資訊並登入
3. 點擊 "📋 選擇資料欄位" 按鈕
4. 在彈出面板中選擇想要的欄位
5. 發送包含患者 UID 的訊息

### 3. 測試範例
```
用戶訊息: "請分析患者 e38f016f-53b4-4587-a9c7-8621d9b879a9 的臨床摘要和 HPO 術語"

選擇欄位: ["clinicalSummary", "hpoTerm"]

結果: LLM 只會收到選擇的欄位資料，而不是完整的患者資料
```

## 技術實現

### 1. 資料過濾邏輯
- 在 `getPatientInfoWithFields` 方法中實現
- 將完整的 Patient 結構轉換為 map
- 根據 `selectedFields` 過濾資料
- 返回過濾後的 JSON 物件

### 2. 前端狀態管理
- `selectedFields`: 存儲選擇的欄位路徑
- `availableFields`: 存儲可用的欄位資訊
- 登入後自動載入可用欄位

### 3. UI/UX 設計
- 響應式設計，支援手機和桌面
- 視覺化欄位類型（string/array）
- 即時更新選擇狀態
- 全選/清除功能

## 優勢
1. **效能優化**: 只傳送需要的資料給 LLM，減少 token 使用量
2. **隱私保護**: 可以選擇性地隱藏敏感資料
3. **成本控制**: 減少不必要的資料傳輸
4. **靈活性**: 根據不同問題選擇相關資料
5. **用戶友好**: 直觀的介面讓用戶輕鬆選擇欄位 
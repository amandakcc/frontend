package main

import (
	"net/http"
	"os"
	"sre-transfer/api"

	"github.com/rs/zerolog/log"
)

func main() {
	router, err := api.NewGinRouter()
	if err != nil {
		log.Fatal().Err(err).Msg("Failed to create http server")
		os.Exit(1)
	}
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	s := &http.Server{
		Handler: router,
		Addr:    "0.0.0.0:" + port,
	}
	if err := s.ListenAndServe(); err != nil {
		log.Fatal().Err(err).Msg("Failed to start server")
		os.Exit(1)
	}
}

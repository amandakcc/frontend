let sessionId = null;
let authToken = null;
let serverUrl = null;

// 登入函數
async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const serverUrlInput = document.getElementById('serverUrl').value;
    const openaiApiKey = document.getElementById('openaiApiKey').value;
    const openaiBaseUrl = document.getElementById('openaiBaseUrl').value;
    
    if (!username || !password) {
        alert('Please enter your username and password');
        return;
    }

    // 設置服務器地址
    serverUrl = serverUrlInput.trim() || 'http://localhost:8080';
    authToken = btoa(username + ':' + password);
    
    try {
        // 更新 API 配置
        if (openaiApiKey || openaiBaseUrl) {
            const configResponse = await fetch('http://localhost:8081/api/config', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    openaiApiKey: openaiApiKey || '',
                    openaiBaseUrl: openaiBaseUrl || '',
                    serverPort: '8081'
                })
            });

            if (!configResponse.ok) {
                console.warn('Failed to update API configuration');
            }
        }

        // 創建會話
        const response = await fetch('http://localhost:8081/api/chat/session', {
            method: 'POST',
            headers: {
                'Authorization': 'Basic ' + authToken
            }
        });

        if (response.ok) {
            const data = await response.json();
            sessionId = data.sessionId;
            document.getElementById('authForm').style.display = 'none';
            document.querySelector('.chat-container').style.display = 'flex';
            addMessage('bot', 'You can now start chatting.');
        } else {
            alert('Authentication failed, please check your username and password');
        }
    } catch (error) {
        alert('Connection failed, please ensure the server is running');
        console.error('Error:', error);
    }
}

// 發送訊息
async function sendMessage() {
    const input = document.getElementById('messageInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    // 顯示用戶訊息
    addMessage('user', message);
    input.value = '';
    
    // 顯示載入狀態
    showLoading(true);
    
    try {
        const response = await fetch('http://localhost:8081/api/chat/', {
            method: 'POST',
            headers: {
                'Authorization': 'Basic ' + authToken,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                sessionId: sessionId,
                serverUrl: serverUrl
            })
        });

        if (response.ok) {
            const data = await response.json();
            addMessage('bot', data.response);
        } else {
            addError('Failed to send message, please try again');
        }
    } catch (error) {
        addError('Connection error, please check server status');
        console.error('Error:', error);
    } finally {
        showLoading(false);
    }
}

// 添加訊息到聊天界面
function addMessage(type, content) {
    const chatMessages = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${type}`;
    messageDiv.innerHTML = `<div class="message-content">${content}</div>`;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// 添加錯誤訊息
function addError(message) {
    const chatMessages = document.getElementById('chatMessages');
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error';
    errorDiv.textContent = message;
    chatMessages.appendChild(errorDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// 顯示/隱藏載入狀態
function showLoading(show) {
    const loading = document.getElementById('loading');
    const sendButton = document.getElementById('sendButton');
    const messageInput = document.getElementById('messageInput');
    
    if (show) {
        loading.style.display = 'block';
        sendButton.disabled = true;
        messageInput.disabled = true;
    } else {
        loading.style.display = 'none';
        sendButton.disabled = false;
        messageInput.disabled = false;
        messageInput.focus();
    }
}

// 處理按鍵事件
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

// 頁面載入時聚焦到輸入框
window.onload = async function() {
    try {
        // 獲取當前配置
        const configResponse = await fetch('http://localhost:8081/api/config');
        if (configResponse.ok) {
            const config = await configResponse.json();
            document.getElementById('openaiApiKey').value = config.openaiApiKey || '';
            document.getElementById('openaiBaseUrl').value = config.openaiBaseUrl || '';
        }
    } catch (error) {
        console.log('Failed to get configuration, using default values');
    }
    
    document.getElementById('username').focus();
}; 
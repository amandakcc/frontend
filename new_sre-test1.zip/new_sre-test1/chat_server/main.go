package main

import (
	"log"
	"net/http"
	"os"
	"sync"

	"sre-transfer/api"

	"github.com/gin-gonic/gin"
)

// Config 配置結構
type Config struct {
	OpenAIAPIKey  string `json:"openaiApiKey"`
	OpenAIBaseURL string `json:"openaiBaseUrl"`
	ServerPort    string `json:"serverPort"`
}

var (
	config      *Config
	configLock  sync.RWMutex
	chatService *api.ChatService
	chatLock    sync.RWMutex
)

func main() {
	// 啟動時不初始化 config/chatService
	config = nil
	chatService = nil

	router := gin.Default()

	// CORS
	router.Use(func(c *gin.Context) {
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
		c.Header("Access-Control-Allow-Headers", "Origin, Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	// 健康檢查
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok", "service": "chat-api"})
	})

	// 配置端點
	router.GET("/api/config", func(c *gin.Context) {
		configLock.RLock()
		defer configLock.RUnlock()
		if config == nil {
			c.JSON(404, gin.H{"error": "Config not set"})
			return
		}
		c.JSON(200, config)
	})

	router.POST("/api/config", func(c *gin.Context) {
		var newConfig Config
		if err := c.ShouldBindJSON(&newConfig); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid config"})
			return
		}
		configLock.Lock()
		config = &newConfig
		configLock.Unlock()

		chatLock.Lock()
		chatService = api.NewChatService(config.OpenAIAPIKey, config.OpenAIBaseURL)
		chatLock.Unlock()

		c.JSON(200, gin.H{"message": "Configuration updated successfully"})
	})

	// 靜態文件服務
	router.Static("/static", "./static")
	router.GET("/", func(c *gin.Context) {
		c.Redirect(http.StatusMovedPermanently, "/static/index.html")
	})

	// 聊天 API
	chatGroup := router.Group("/api/chat")
	chatGroup.Use(api.BasicAuthMiddleware())
	{
		chatGroup.POST("/", func(c *gin.Context) {
			chatLock.RLock()
			cs := chatService
			chatLock.RUnlock()
			if cs == nil {
				c.JSON(503, gin.H{"error": "Chat service not initialized"})
				return
			}
			cs.HandleChat(c)
		})
		chatGroup.POST("/session", func(c *gin.Context) {
			chatLock.RLock()
			cs := chatService
			chatLock.RUnlock()
			if cs == nil {
				c.JSON(503, gin.H{"error": "Chat service not initialized"})
				return
			}
			cs.CreateSession(c)
		})
		chatGroup.GET("/session/:sessionId", func(c *gin.Context) {
			chatLock.RLock()
			cs := chatService
			chatLock.RUnlock()
			if cs == nil {
				c.JSON(503, gin.H{"error": "Chat service not initialized"})
				return
			}
			cs.GetSession(c)
		})
		chatGroup.GET("/session/:sessionId/history", func(c *gin.Context) {
			chatLock.RLock()
			cs := chatService
			chatLock.RUnlock()
			if cs == nil {
				c.JSON(503, gin.H{"error": "Chat service not initialized"})
				return
			}
			cs.GetChatHistory(c)
		})
	}

	// 啟動服務器（預設 8081，或用戶設定的 port）
	port := os.Getenv("PORT")
	if config != nil && config.ServerPort != "" {
		port = config.ServerPort
	}
	if port == "" {
		port = "8081"
	}
	log.Printf("Starting chat server on port %s", port)
	if err := router.Run(":" + port); err != nil {
		log.Fatalf("Failed to start server: %v", err)
	}
}

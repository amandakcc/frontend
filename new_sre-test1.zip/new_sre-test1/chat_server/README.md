# Chat Server

這是一個獨立的聊天服務器，提供 LLM 聊天功能和會話管理。

## 快速開始

### 1. 啟動服務器

```bash
# 在項目根目錄運行
go run chat_server/main.go
```

### 2. 環境變量配置

```bash
# OpenAI 配置
export OPENAI_API_KEY="your-api-key"
export OPENAI_BASE_URL="http://10.228.8.3:10240/v1"

# 服務器配置
export SERVER_PORT="8081"
```

### 3. 健康檢查

```bash
curl http://localhost:8081/health
```

## API 端點

### 認證

所有 API 端點都需要基本認證：

```bash
# 使用 curl 時添加認證頭
-H "Authorization: Basic <base64-encoded-credentials>"
```

### 1. 創建會話

```bash
curl -X POST http://localhost:8081/api/chat/session \
  -H "Authorization: Basic <base64-encoded-credentials>"
```

**響應:**
```json
{
  "sessionId": "session_1234567890",
  "message": "Session created successfully"
}
```

### 2. 發送聊天消息

```bash
curl -X POST http://localhost:8081/api/chat/ \
  -H "Authorization: Basic <base64-encoded-credentials>" \
  -H "Content-Type: application/json" \
  -d '{
    "message": "Can you get patient information for UID e38f016f-53b4-4587-a9c7-8621d9b879a9?",
    "sessionId": "session_1234567890"
  }'
```

**響應:**
```json
{
  "response": "I'll help you get the patient information...",
  "usedFunction": true,
  "functionName": "get_patient_info",
  "sessionId": "session_1234567890",
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### 3. 獲取會話信息

```bash
curl -X GET http://localhost:8081/api/chat/session/session_1234567890 \
  -H "Authorization: Basic <base64-encoded-credentials>"
```

### 4. 獲取聊天歷史

```bash
curl -X GET http://localhost:8081/api/chat/session/session_1234567890/history \
  -H "Authorization: Basic <base64-encoded-credentials>"
```

## 使用示例

### JavaScript 示例

```javascript
// 創建會話
const createSession = async () => {
  const response = await fetch('http://localhost:8081/api/chat/session', {
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + btoa('username:password')
    }
  });
  const data = await response.json();
  return data.sessionId;
};

// 發送消息
const sendMessage = async (message, sessionId) => {
  const response = await fetch('http://localhost:8081/api/chat/', {
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + btoa('username:password'),
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      message: message,
      sessionId: sessionId
    })
  });
  return await response.json();
};

// 使用示例
const chat = async () => {
  const sessionId = await createSession();
  const response = await sendMessage(
    "Hello, how are you?",
    sessionId
  );
  console.log(response);
};
```

### Python 示例

```python
import requests
import base64

# 認證
username = "your_username"
password = "your_password"
credentials = base64.b64encode(f"{username}:{password}".encode()).decode()

headers = {
    "Authorization": f"Basic {credentials}",
    "Content-Type": "application/json"
}

# 創建會話
response = requests.post(
    "http://localhost:8081/api/chat/session",
    headers={"Authorization": f"Basic {credentials}"}
)
session_id = response.json()["sessionId"]

# 發送消息
response = requests.post(
    "http://localhost:8081/api/chat/",
    headers=headers,
    json={
        "message": "Can you get patient information for UID e38f016f-53b4-4587-a9c7-8621d9b879a9?",
        "sessionId": session_id
    }
)
print(response.json())
```

## 端口配置

- **默認端口**: 8081
- **原始服務器**: 8080 (main.go)
- **聊天服務器**: 8081 (chat_server/main.go)

兩個服務器可以同時運行，不會衝突。

## 故障排除

### 1. 端口衝突

如果端口 8081 被佔用，可以通過環境變量修改：

```bash
export SERVER_PORT="8082"
```

### 2. 認證錯誤

確保使用正確的用戶名和密碼，並且已經通過基本認證。

### 3. OpenAI API 錯誤

檢查 `OPENAI_API_KEY` 和 `OPENAI_BASE_URL` 是否正確設置。

## 開發

### 添加新功能

1. 在 `api/chat.go` 中添加新的方法
2. 在 `chat_server/main.go` 中註冊新的路由
3. 更新文檔

### 測試

```bash
# 測試健康檢查
curl http://localhost:8081/health

# 測試聊天功能
curl -X POST http://localhost:8081/api/chat/ \
  -H "Authorization: Basic <base64-encoded-credentials>" \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello"}'
``` 
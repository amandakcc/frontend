package sso

import (
	"bytes"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"regexp"
	"strings"
	"time"

	"github.com/rs/zerolog/log"
)

type Environment string

const (
	Production    Environment = "cf.genomeproject.hk"
	Preproduction Environment = "cf-pp.genomeproject.hk"
	Staging       Environment = "cf-stg.genomeproject.hk"
)

type Application = string

const (
	Sre              Application = "sre"
	ClinicalFrontend Application = "app"
)

type ClinicalFrontendLoginStartPayload struct {
	AppEnv      string `json:"app_env"`
	AppName     string `json:"app_name"`
	AppVersion  string `json:"app_version"`
	RedirectUri string `json:"redirect_uri"`
}

type ClinicalFrontendLoginEndPayload struct {
	Code        string `json:"code"`
	RedirectUri string `json:"redirect_uri"`
	State       string `json:"state"`
}

type ClinicalFrontendAuthUrlResponse struct {
	AuthUrl string `json:"authUrl"`
}

func (client *Client) GetLoginRequest() (*http.Request, error) {
	switch client.App {
	case Sre:
		loginUrl := fmt.Sprintf("https://sre.%s?next=/desktop/hub/home", client.Env)
		req, err := http.NewRequest("GET", loginUrl, nil)
		if err != nil {
			return nil, fmt.Errorf("failed to create new reqeust, %w", err)
		}
		return req, nil
	case ClinicalFrontend:
		appEnvMap := map[Environment]string{
			Staging:       "staging",
			Preproduction: "preproduction",
			Production:    "production",
		}
		loginUrl := fmt.Sprintf("https://auth.api.%s/session/login-start", client.Env)
		payload := ClinicalFrontendLoginStartPayload{
			AppEnv:      appEnvMap[client.Env],
			AppName:     "Clinical Frontend",
			AppVersion:  "43.0.1",
			RedirectUri: "https://app.cf-stg.genomeproject.hk/login",
		}
		b, err := json.Marshal(payload)
		if err != nil {
			return nil, fmt.Errorf("failed to construct json request, %w", err)
		}
		resp, err := client.Post(loginUrl, "application/json", bytes.NewReader(b))
		if err != nil {
			return nil, fmt.Errorf("failed to get auth url, %w", err)
		}
		defer resp.Body.Close()
		b, err = io.ReadAll(resp.Body)
		if err != nil {
			return nil, fmt.Errorf("failed to read auth url response")
		}

		var authUrlResp ClinicalFrontendAuthUrlResponse
		json.Unmarshal(b, &authUrlResp)
		if authUrlResp.AuthUrl == "" {
			return nil, fmt.Errorf("failed to extract auth url from response")
		}
		req, err := http.NewRequest("GET", authUrlResp.AuthUrl, nil)
		if err != nil {
			return nil, fmt.Errorf("failed to create new reqeust, %w", err)
		}
		return req, nil

	default:
		return nil, errors.New("unsupported application")
	}
}

type LoginParams struct {
	PublicKey      string
	SessionDataKey string
	RedirectedUrl  string
}

type LoginOtpParams struct {
	OtpCode        string `json:"OTPCode"`
	SessionDataKey string `json:"sessionDataKey"`
	ResendCode     bool   `json:"resendCode"`
}

type CommonAuthParams struct {
	Username    string
	Password    string
	LoginParams *LoginParams
}

type Client struct {
	http.Client
	Name              string
	LastUpdated       time.Time
	Env               Environment
	App               Application
	OtpSessionDataKey string
	OtpReferer        string
}

type CommonAuthResult struct {
	RequiresOtp    bool
	SessionDataKey string
	RedirectedUrl  string
}

type OidcAuthSession struct {
	Code         string
	State        string
	SessionState string
}

func FindSessionKey(content []byte) (string, error) {
	sessionKey, err := regexp.Compile(`[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}`)
	if err != nil {
		return "", fmt.Errorf("failed to compile uuid regexp")
	}
	sessionKeyMatch := sessionKey.FindSubmatch(content)
	if len(sessionKeyMatch) == 0 {
		return "", fmt.Errorf("failed to find session data key")
	}
	return string(sessionKeyMatch[0]), nil
}

func (client *Client) GetAuthorization(req *http.Request) (*LoginParams, error) {
	loginResp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to get login: %v", err)
	}
	defer loginResp.Body.Close()

	b, err := io.ReadAll(loginResp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read login page: %w", err)
	}

	pubKey, err := regexp.Compile(`window\.PUBLIC_KEY=\"-----BEGIN PUBLIC KEY-----(.*)-----END PUBLIC KEY-----\"`)
	if err != nil {
		return nil, fmt.Errorf("failed to compile pubkey regexp: %w", err)
	}
	pubKeyMatch := pubKey.FindSubmatch(b)
	if len(pubKeyMatch) != 2 {
		return nil, fmt.Errorf("failed to find public key")
	}
	formattedPubKey := "-----BEGIN PUBLIC KEY-----\n" + string(pubKeyMatch[1]) + "\n-----END PUBLIC KEY-----\n"
	sessionKey, err := FindSessionKey(b)
	if err != nil {
		return nil, fmt.Errorf("failed to find session key: %w", err)
	}
	param := LoginParams{
		PublicKey:      formattedPubKey,
		SessionDataKey: sessionKey,
		RedirectedUrl:  loginResp.Request.URL.String(),
	}

	return &param, nil
}

func (client *Client) SubmitOtp(otp string) error {
	if client.OtpSessionDataKey == "" {
		return fmt.Errorf("no session data key provided, probably not logged in or OTP is not required")
	}
	data := url.Values{}
	data.Set("OTPCode", otp)
	data.Set("sessionDataKey", client.OtpSessionDataKey)
	data.Set("resendCode", "false")
	req, err := http.NewRequest("POST", fmt.Sprintf("https://sso.%s/commonauth", client.Env), strings.NewReader(data.Encode()))
	if err != nil {
		return fmt.Errorf("failed to create request: %w", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Referer", client.OtpReferer)
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to send otp request: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("failed to submit otp: %s", resp.Status)
	}
	_, err = io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read response body: %w", err)
	}

	client.OtpSessionDataKey = ""
	client.OtpReferer = ""
	return nil
}

func (client *Client) PostCommonAuth(params *CommonAuthParams) (*CommonAuthResult, *OidcAuthSession, error) {
	result, err := EncryptData(params.LoginParams.PublicKey, []byte(params.Password))
	if err != nil {
		return nil, nil, fmt.Errorf("failed to encrypt data: %w", err)
	}
	b, err := json.Marshal(result)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to encode encrypted password to json: %w", err)
	}
	data := url.Values{}
	data.Set("sessionDataKey", params.LoginParams.SessionDataKey)
	data.Set("usernameUserInput", params.Username)
	data.Set("username", params.Username)
	data.Set("password", "")
	data.Set("credentials", base64.StdEncoding.EncodeToString(b))

	req, err := http.NewRequest("POST", fmt.Sprintf("https://sso.%s/commonauth", client.Env), strings.NewReader(data.Encode()))
	if err != nil {
		return nil, nil, fmt.Errorf("failed to create request for commonauth: %w", err)
	}
	req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	req.Header.Set("Referer", params.LoginParams.RedirectedUrl)
	resp, err := client.Do(req)
	if err != nil {
		return nil, nil, fmt.Errorf("failed to send request to commonauth: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, nil, fmt.Errorf("failed to login: %d", resp.StatusCode)
	}
	query := resp.Request.URL.Query()
	if failed := query.Get("authFailure"); failed == "true" {
		return nil, nil, fmt.Errorf("commonauth failed: %s", failed)
	}
	if auth := query.Get("authenticators"); auth == "EmailOTP" {
		b, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to read email otp response body: %w", err)
		}

		key, err := FindSessionKey(b)
		if err != nil {
			return nil, nil, fmt.Errorf("failed to find session key in email otp page: %w", err)
		}
		return &CommonAuthResult{RequiresOtp: true, SessionDataKey: key, RedirectedUrl: resp.Request.URL.String()}, nil, nil
	}
	return &CommonAuthResult{
			RequiresOtp: false,
		}, &OidcAuthSession{
			Code:         query.Get("code"),
			State:        query.Get("state"),
			SessionState: query.Get("session_state"),
		}, nil
}

func (client *Client) GetLoginContext(params *LoginParams) error {
	q := url.Values{}
	q.Set("sessionDataKey", params.SessionDataKey)
	q.Set("relyingParty", "HKGI_SSO_API")
	q.Set("tenantDomain", "carbon.super")
	q.Set("_", fmt.Sprintf("%d", time.Now().UnixMilli()))

	req, err := http.NewRequest("GET", fmt.Sprintf("https://sso.%s/logincontext?", client.Env)+q.Encode(), nil)
	if err != nil {
		return fmt.Errorf("failed to create request for login context: %w", err)
	}
	req.Header.Set("Referer", params.RedirectedUrl)
	resp, err := client.Do(req)
	if err != nil {
		return fmt.Errorf("failed to get login context: %w", err)
	}
	defer resp.Body.Close()
	b, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read login context: %w", err)
	}
	if string(b) != `{"status":"success"}` {
		return fmt.Errorf("failed to get login context: %s", string(b))
	}
	return nil
}

func (client *Client) LoginEnd(result OidcAuthSession) error {
	session := ClinicalFrontendLoginEndPayload{
		State:       result.State,
		Code:        result.Code,
		RedirectUri: fmt.Sprintf("https://%s.%s/login", client.App, client.Env),
	}
	b, err := json.Marshal(session)
	if err != nil {
		return fmt.Errorf("failed to construct login end json")
	}
	log.Debug().Msg("sending login-end request")
	resp, err := client.Post(fmt.Sprintf("https://auth.api.%s/session/login-end", client.Env), "application/json", bytes.NewReader(b))
	if err != nil {
		return fmt.Errorf("failed to send login-end request")
	}
	defer resp.Body.Close()
	return nil
}

func NewClient(app Application, env Environment, user string, password string) (*Client, error) {
	jar, err := cookiejar.New(nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create cookie jar: %w", err)
	}

	client := &Client{
		Client:      http.Client{Jar: jar},
		Name:        user,
		LastUpdated: time.Now(),
		Env:         env,
		App:         app,
	}

	req, err := client.GetLoginRequest()
	if err != nil {
		return nil, fmt.Errorf("failed to get application login url: %w", err)
	}

	params, err := client.GetAuthorization(req)
	if err != nil {
		return nil, fmt.Errorf("failed to get auth params: %w", err)
	}
	if err := client.GetLoginContext(params); err != nil {
		return nil, fmt.Errorf("failed to get auth context: %w", err)
	}
	result, oidcSession, err := client.PostCommonAuth(&CommonAuthParams{
		Username:    user,
		Password:    password,
		LoginParams: params,
	})
	if err != nil {
		return nil, fmt.Errorf("failed to post commonauth: %w", err)
	}
	if result.RequiresOtp {
		client.OtpSessionDataKey = result.SessionDataKey
		client.OtpReferer = result.RedirectedUrl
	}
	if oidcSession != nil && oidcSession.Code != "" {
		client.LoginEnd(*oidcSession)
	}

	return client, nil
}

package sso

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/ecdh"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"fmt"
)

type EncryptionResult struct {
	Ciphertext []byte
	IV         []byte
	Tag        []byte
}

type EncryptedPayload struct {
	EncryptedData      string `json:"encryptedData"`
	IV                 string `json:"iv"`
	Tag                string `json:"tag"`
	ClientPublicKeyPem string `json:"clientPublicKeyPem"`
	KeyType            string `json:"keyType"`
}

func EncryptData(serverPublicKeyPem string, data []byte) (*EncryptedPayload, error) {
	// encrypt data with AES-GCM, with ECDH shared secret
	// parse public key in PEM format
	block, _ := pem.Decode([]byte(serverPublicKeyPem))
	if block == nil {
		return nil, errors.New("failed to decode PEM block")
	}

	ecPub, err := x509.ParsePKIXPublicKey(block.Bytes)
	if err != nil {
		return nil, fmt.Errorf("failed to parse public key as ECDSA: %v", err)
	}

	// assume hkgi-sso public key to be ECDSA
	ecdsaPub, ok := ecPub.(*ecdsa.PublicKey)
	if !ok {
		return nil, errors.New("public key is not ECDSA")
	}

	// derive shared secret
	// determine the curve which the public key is on, at the moment of writing its P256
	var ecdhCurve ecdh.Curve

	switch ecdsaPub.Curve {
	case elliptic.P256():
		ecdhCurve = ecdh.P256()
	case elliptic.P384():
		ecdhCurve = ecdh.P384()
	case elliptic.P521():
		ecdhCurve = ecdh.P521()
	default:
		return nil, errors.New("input public key is on unsupported curve")
	}

	// generate a keypair on the curve and derive the shared secret using ECDH
	clientPriv, err := ecdhCurve.GenerateKey(rand.Reader)
	if err != nil {
		return nil, fmt.Errorf("failed to generate ECDH key pair: %v", err)
	}

	ecdhPub, err := ecdsaPub.ECDH()
	if err != nil {
		return nil, fmt.Errorf("failed to convert ECDSA public key to ECDH public key: %v", err)
	}

	sharedSecret, err := clientPriv.ECDH(ecdhPub)
	if err != nil {
		return nil, fmt.Errorf("failed to derive shared secret: %v", err)
	}

	// encrypt with AES using the shared secret
	encResult, err := EncryptWithAES(sharedSecret, data)
	if err != nil {
		return nil, err
	}

	// convert client public key to PEM
	clientPubBytes, err := x509.MarshalPKIXPublicKey(clientPriv.PublicKey())
	if err != nil {
		return nil, fmt.Errorf("failed to marshal client public key: %v", err)
	}
	clientPubPem := pem.EncodeToMemory(&pem.Block{
		Type:  "PUBLIC KEY",
		Bytes: clientPubBytes,
	})

	return &EncryptedPayload{
		EncryptedData:      base64.StdEncoding.EncodeToString(encResult.Ciphertext),
		IV:                 base64.StdEncoding.EncodeToString(encResult.IV),
		ClientPublicKeyPem: string(clientPubPem),
		Tag:                base64.StdEncoding.EncodeToString(encResult.Tag),
		KeyType:            "ECDSA",
	}, nil
}

func EncryptWithAES(key, data []byte) (*EncryptionResult, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, fmt.Errorf("failed to create AES cipher: %v", err)
	}

	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, fmt.Errorf("failed to create GCM: %v", err)
	}

	iv := make([]byte, gcm.NonceSize())
	if _, err := rand.Read(iv); err != nil {
		return nil, fmt.Errorf("failed to generate IV: %v", err)
	}

	ciphertext := gcm.Seal(nil, iv, data, nil)

	// AES-GCM tag is fixed 16 bit in Golang implementation, appended to ciphertext
	return &EncryptionResult{
		Ciphertext: ciphertext[:len(ciphertext)-16],
		Tag:        ciphertext[len(ciphertext)-16:],
		IV:         iv,
	}, nil
}

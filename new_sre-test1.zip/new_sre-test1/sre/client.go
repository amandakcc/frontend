package sre

import "sre-transfer/sso"

type Client struct {
	sso.Client
}

func NewClient(client *sso.Client) *Client {
	return &Client{*client}
}

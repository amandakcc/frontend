package sre

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/url"
	"regexp"
	"strconv"
)

type BringInRequestAction = string

const (
	ActionApprove BringInRequestAction = "approve"
	ActionReject  BringInRequestAction = "reject"
)

type ProceedParams struct {
	Reason string               `json:"reason"`
	Type   BringInRequestAction `json:"type"`
}

type BringInRequest struct {
	ID                string `json:"id"`
	SupervisorName    string `json:"supervisor_name"`
	UserName          string `json:"user_name"`
	RequestTime       string `json:"request_time"`
	Path              string `json:"path"`
	DisplayName       string `json:"display_name"`
	Email             string `json:"email"`
	TeamName          string `json:"team_name"`
	Description       string `json:"description"`
	InfectedFileCount int    `json:"infected_file_count"`
}

type FilePreview struct {
	Path          string `json:"path"`
	Name          string `json:"name"`
	Size          int64  `json:"size"`
	Extension     string `json:"extension"`
	Modified      string `json:"modified"`
	Mode          int64  `json:"mode"`
	IsDir         bool   `json:"isDir"`
	IsSymlink     bool   `json:"isSymlink"`
	Type          string `json:"type"`
	TextImmutable bool   `json:"textImmutable"`
	Content       string `json:"content"`
}

func (client *Client) GetBaseUrl() string {
	return fmt.Sprintf("https://sre.%s", client.Env)
}

func (client *Client) GetFile(r *BringInRequest, file string) (*FilePreview, error) {
	folderUrl, err := url.JoinPath(client.GetBaseUrl(), "/admin/user/admin/app/api/resources/user_request_storage/", r.SupervisorName, "/bring_in_file/request", r.UserName, r.ID)
	if err != nil {
		return nil, fmt.Errorf("failed to build bring in request base url: %w", err)
	}

	resp, err := client.Get(folderUrl + "/" + file)
	if err != nil {
		return nil, fmt.Errorf("failed to send request to fetch antivirus log: %w", err)
	}
	defer resp.Body.Close()
	var preview FilePreview
	if err := json.NewDecoder(resp.Body).Decode(&preview); err != nil {
		return nil, fmt.Errorf("failed to decode response body: %w", err)
	}
	return &preview, nil
}

func (client *Client) Proceed(r *BringInRequest, action BringInRequestAction, reason string) error {
	folderUrl, err := url.JoinPath(client.GetBaseUrl(), "/admin/user/admin/api/bring_in_request", r.SupervisorName, r.UserName, r.ID)
	if err != nil {
		return fmt.Errorf("failed to build approval url: %w", err)
	}

	params := ProceedParams{
		Type:   action,
		Reason: reason,
	}
	b, err := json.Marshal(params)
	if err != nil {
		return fmt.Errorf("failed to marshal request body: %w", err)
	}
	resp, err := client.Post(folderUrl+"/approval", "text/plain;charset=UTF-8", bytes.NewBuffer(b))
	if err != nil {
		return fmt.Errorf("failed to send request to approval endpoint: %w", err)
	}

	defer resp.Body.Close()
	_, err = io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Errorf("failed to read response body: %w", err)
	}
	return nil
}

func (client *Client) ListBringInRequest() ([]BringInRequest, error) {
	listUrl, err := url.JoinPath(client.GetBaseUrl(), "/admin/user/admin/api/bring_in_request")
	if err != nil {
		return nil, fmt.Errorf("failed to build list url: %w", err)
	}
	resp, err := client.Get(listUrl)
	if err != nil {
		return nil, fmt.Errorf("failed to send list request of bring in request: %w", err)
	}
	defer resp.Body.Close()

	var list []BringInRequest
	if err := json.NewDecoder(resp.Body).Decode(&list); err != nil {
		return nil, fmt.Errorf("failed to decode bring in request response: %w", err)
	}
	for idx, r := range list {
		preview, err := client.GetFile(&r, "antivirus.log")
		if err != nil {
			return nil, fmt.Errorf("failed to fetch antivirus log: %w", err)
		}
		infectedFileRegexp, err := regexp.Compile(`Infected files: (\d)`)
		if err != nil {
			return nil, fmt.Errorf("failed to compile infect files regexp: %w", err)
		}
		infectedFileMatch := infectedFileRegexp.FindSubmatch([]byte(preview.Content))

		if len(infectedFileMatch) != 2 {
			return nil, fmt.Errorf("failed to find infected file line")
		}
		infectedFileCount, err := strconv.Atoi(string(infectedFileMatch[1]))
		if err != nil {
			return nil, fmt.Errorf("failed to convert infected file count to number: %w", err)
		}

		// find request description
		description, err := client.GetFile(&r, "request_description")
		if err != nil {
			return nil, fmt.Errorf("failed to send request to fetch request description: %w", err)
		}
		r.Description = description.Content
		r.InfectedFileCount = infectedFileCount
		list[idx] = r
	}

	return list, nil
}

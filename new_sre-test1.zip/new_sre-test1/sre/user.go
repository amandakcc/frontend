package sre

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/url"
)

type BringInRequestParams struct {
	Description string `json:"description"`
}

type BringInRequestResponse struct {
	ID          string `json:"id"`
	RequestTime string `json:"request_time"`
	Status      string `json:"status"`
}

func (client *Client) UploadSreFile(file string, reader io.Reader) error {
	// upload a file to transfer console, it will
	// 1. create an empty file with POST request
	// 2. check if the file exists with HEAD request
	// 3. patch to append range with PATCH request, specifically append <Content-Length> bit of data from <Upload-Offset> bit

	fileUrl, err := url.JoinPath(client.GetBaseUrl(), "/transfer/user", client.Name, "/app/api/tus/bring_in_file", file)
	fileUrl += "?override=false"
	if err != nil {
		return fmt.Errorf("failed to build file url: %w", err)
	}
	shell, err := client.Post(fileUrl, "text/plain", nil)
	if err != nil {
		return fmt.Errorf("failed to create empty file: %w", err)
	}
	defer shell.Body.Close()
	if shell.StatusCode != 201 {
		return fmt.Errorf("failed to create empty file: %s", shell.Status)
	}

	confirm, err := client.Head(fileUrl)
	if err != nil {
		return fmt.Errorf("failed to check the existence of file: %w", err)
	}
	if confirm.StatusCode != 200 {
		return fmt.Errorf("the file does not exists: %s", confirm.Status)
	}

	// upload in 10MB chunk
	// must be sequential at the moment, multi-thread uploading would result in 409 Conflict
	counter := int64(0)
	chunkSize := int64(10485760)
	end := false

	for {
		data := bytes.NewBuffer(make([]byte, 0, chunkSize))
		n, err := io.CopyN(data, reader, chunkSize)

		if err != nil {
			if err == io.EOF {
				end = true
			} else {
				return fmt.Errorf("failed to read data: %w", err)
			}
		}
		req, err := http.NewRequest("PATCH", fileUrl, data)
		if err != nil {
			return fmt.Errorf("failed to create request for upload: %w", err)
		}
		req.Header.Set("Content-Type", "application/offset+octet-stream")
		req.Header.Set("Content-Length", fmt.Sprintf("%d", n))
		req.Header.Set("Upload-Offset", fmt.Sprintf("%d", counter))

		resp, err := client.Do(req)
		if err != nil {
			return fmt.Errorf("failed to upload file: %w", err)
		}
		defer resp.Body.Close()

		switch resp.StatusCode {
		case 200:
			return fmt.Errorf("file already exists, check user storage or pending bring in request, file: %s", file)
		case 409:
			return fmt.Errorf("file already exists and range to be written overlaps with existing data, file: %s", file)
		case 204:
			counter += n
		}

		if end {
			break
		}
	}
	return nil
}

func (client *Client) SubmitBringInRequest(description string) (*BringInRequestResponse, error) {
	requestUrl, err := url.JoinPath(client.GetBaseUrl(), "/transfer/user", client.Name, "/api/bring_in_request")
	if err != nil {
		return nil, fmt.Errorf("failed to build bring in request url: %w", err)
	}
	b, err := json.Marshal(BringInRequestParams{description})
	if err != nil {
		return nil, fmt.Errorf("failed to encode request params to json: %w", err)
	}
	bringIn, err := client.Post(requestUrl, "text/plain;charset=UTF-8", bytes.NewBuffer(b))
	if err != nil {
		return nil, fmt.Errorf("failed to create bring in request: %w", err)
	}
	defer bringIn.Body.Close()

	var r BringInRequestResponse
	if err := json.NewDecoder(bringIn.Body).Decode(&r); err != nil {
		return nil, fmt.Errorf("failed to decode bring in request: %w", err)
	}
	return &r, nil
}

package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
	"syscall"

	"sre-transfer/api"

	"github.com/sashabaranov/go-openai"
	"golang.org/x/term"
)

// PatientInfo use the existing Patient struct
type PatientInfo = api.Patient

// ErrorResponse error response struct
type ErrorResponse struct {
	Error string `json:"error"`
}

// getPatientInfo get patient information
func getPatientInfo(UID string) interface{} {
	// prompt user to enter username and password
	fmt.Println("Enter the username and password to get the patient information")

	fmt.Print("username: ")
	reader := bufio.NewReader(os.Stdin)
	username, err := reader.ReadString('\n')
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("error reading username: %v", err)}
	}
	username = strings.TrimSpace(username)

	fmt.Print("password: ")
	bytePassword, err := term.ReadPassword(int(syscall.Stdin))
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("error reading password: %v", err)}
	}
	fmt.Println() // new line after password input
	password := string(bytePassword)

	url := fmt.Sprintf("http://localhost:8080/patient/%s", UID)

	// create HTTP request
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("error creating request: %v", err)}
	}

	// set basic authentication
	req.SetBasicAuth(username, password)

	// send request
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("error 1: %v", err)}
	}
	defer resp.Body.Close()

	// check response status
	if resp.StatusCode != http.StatusOK {
		return ErrorResponse{Error: fmt.Sprintf("error 1: HTTP %d", resp.StatusCode)}
	}

	// read response content
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("error 2: %v", err)}
	}

	// parse JSON response
	var patientInfo PatientInfo
	if err := json.Unmarshal(body, &patientInfo); err != nil {
		return ErrorResponse{Error: fmt.Sprintf("error 2: %v", err)}
	}

	return patientInfo
}

// chatWithFunctionCall use function call chat
func chatWithFunctionCall(client *openai.Client, userMessage string) (string, error) {
	// define tools
	tools := []openai.Tool{
		{
			Type: "function",
			Function: &openai.FunctionDefinition{
				Name:        "get_patient_info",
				Description: "Return the patient information from clinical frontend",
				Parameters: map[string]interface{}{
					"type": "object",
					"properties": map[string]interface{}{
						"UID": map[string]interface{}{
							"type":        "string",
							"description": "With the patient UID , follow the user question to analyze the patient condition",
						},
					},
					"required": []string{"UID"},
				},
			},
		},
	}

	// create message
	messages := []openai.ChatCompletionMessage{
		{
			Role:    openai.ChatMessageRoleUser,
			Content: userMessage,
		},
	}

	ctx := context.Background()

	// first call
	req := openai.ChatCompletionRequest{
		Model:       "Qwen/Qwen3-235B-A22B-MLX-8bit",
		Messages:    messages,
		Temperature: 0.1,
		// MaxTokens:   100,
		TopP:       0.15,
		Tools:      tools,
		ToolChoice: "auto",
	}

	resp, err := client.CreateChatCompletion(ctx, req)
	if err != nil {
		return "", fmt.Errorf("error in first API call: %v", err)
	}

	message := resp.Choices[0].Message

	// if there is a function call, process it
	if len(message.ToolCalls) > 0 {
		for _, toolCall := range message.ToolCalls {
			functionName := toolCall.Function.Name
			var functionArgs map[string]interface{}

			if err := json.Unmarshal([]byte(toolCall.Function.Arguments), &functionArgs); err != nil {
				return "", fmt.Errorf("error parsing function arguments: %v", err)
			}

			var functionResult interface{}

			if functionName == "get_patient_info" {
				if UID, ok := functionArgs["UID"].(string); ok {
					functionResult = getPatientInfo(UID)
				} else {
					functionResult = ErrorResponse{Error: "UID parameter is required"}
				}
			} else {
				functionResult = ErrorResponse{Error: fmt.Sprintf("unknown function: %s", functionName)}
			}

			// convert function result to JSON string
			resultJSON, err := json.Marshal(functionResult)
			if err != nil {
				return "", fmt.Errorf("error marshaling function result: %v", err)
			}

			// add function result to message
			messages = append(messages, openai.ChatCompletionMessage{
				Role:       openai.ChatMessageRoleTool,
				ToolCallID: toolCall.ID,
				Content:    string(resultJSON),
			})
		}

		// second call, let AI respond based on function result
		req2 := openai.ChatCompletionRequest{
			Model:       "Qwen/Qwen3-235B-A22B-MLX-8bit",
			Messages:    messages,
			Temperature: 0.1,
			Tools:       tools,
			ToolChoice:  "none", // no more function call
		}

		resp2, err := client.CreateChatCompletion(ctx, req2)
		if err != nil {
			return "", fmt.Errorf("error in second API call: %v", err)
		}

		return resp2.Choices[0].Message.Content, nil
	} else {
		// if there is no function call, return response
		return message.Content, nil
	}
}

func main() {
	// create OpenAI client
	config := openai.DefaultConfig("NdaVD5jNmNYJCXTkhNOrDfx9qFiLUeyT") //  apikey
	config.BaseURL = "http://10.228.8.3:10240/v1"
	client := openai.NewClientWithConfig(config)

	// simple input and response
	userQuestion := "Can you get patient information for UID e38f016f-53b4-4587-a9c7-8621d9b879a9?"

	result, err := chatWithFunctionCall(client, userQuestion)
	if err != nil {
		log.Fatalf("Error in chat with function call: %v", err)
	}

	fmt.Printf("Response: %s\n", result)
}

package cmd

import (
	"net/http"
	"os"

	"sre-transfer/api"

	"github.com/rs/zerolog/log"

	"github.com/spf13/cobra"
)

// rootCmd represents the base command when called without any subcommands
var rootCmd = &cobra.Command{
	Use:   "adminportal",
	Short: "Adminportal Server",
}

var serverCmd = &cobra.Command{
	Use:   "server",
	Short: "Start Admin Portal Server",
	Run: func(cmd *cobra.Command, args []string) {
		router, err := api.NewGinRouter()
		if err != nil {
			log.Fatal().Err(err).Msg("Failed to create http server")
			os.Exit(1)
		}
		port := os.Getenv("PORT")
		if port == "" {
			port = "8080"
		}
		s := &http.Server{
			Handler: router,
			Addr:    "0.0.0.0:" + port,
		}
		if err := s.ListenAndServe(); err != nil {
			log.Fatal().Err(err).Msg("Failed to start server")
			os.Exit(1)
		}
	},
}

func Execute() {
	err := rootCmd.Execute()
	if err != nil {
		os.Exit(1)
	}
}

func init() {
	rootCmd.AddCommand(serverCmd)
	rootCmd.Flags().BoolP("toggle", "t", false, "Help message for toggle")
}

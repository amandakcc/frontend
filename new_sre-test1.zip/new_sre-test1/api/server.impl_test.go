package api

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestExtraEndpoints(t *testing.T) {
	server, err := NewGinRouter()
	if err != nil {
		t.Fatal("failed to initialize engine")
	}
	for _, endpoint := range []string{"/docs", "/openapi.json"} {
		req, err := http.NewRequest("GET", endpoint, nil)
		if err != nil {
			t.Errorf("failed to create http request")
		}
		w := httptest.NewRecorder()
		server.ServeHTTP(w, req)
		if w.Code != http.StatusOK {
			t.Errorf("endpoint %s failed, expected 200, got %d", endpoint, w.Code)
		}
	}
}

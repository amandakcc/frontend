package api

//go:generate go tool oapi-codegen --config oapi-codegen.yaml openapi.yaml

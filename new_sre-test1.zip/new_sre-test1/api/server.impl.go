package api

import (
	"context"
	"embed"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"sre-transfer/sre"
	"sre-transfer/sso"
	"strings"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/jellydator/ttlcache/v3"
)

//go:embed public/*
var staticFiles embed.FS

type Server struct{}

var _ StrictServerInterface = (*Server)(nil)

func NewServer() Server {
	return Server{}
}

func Ptr[T any](i T) *T {
	return &i
}

func (Server) CheckAlive(ctx context.Context, request CheckAliveRequestObject) (CheckAliveResponseObject, error) {
	return CheckAlive200TextResponse("ok"), nil
}

func (s Server) Login(ctx context.Context, request LoginRequestObject) (LoginResponseObject, error) {

	ssoClient, err := s.GetClient(ctx, request.Body.Application, request.Body.Environment)
	if err != nil {
		return Login401JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to login in %s", err))}}, nil
	}
	return Login200JSONResponse{Success: Ptr(true), RequiredOtp: Ptr(ssoClient.OtpSessionDataKey != "")}, nil
}

func (s Server) SubmitOtp(ctx context.Context, request SubmitOtpRequestObject) (SubmitOtpResponseObject, error) {
	ssoClient, err := s.GetClient(ctx, request.Body.Application, request.Body.Environment)
	if err != nil {
		return SubmitOtp400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to login in %s", err))}}, nil
	}
	if err := ssoClient.SubmitOtp(request.Body.Otp); err != nil {
		return SubmitOtp400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to submit otp, %s", err))}}, nil
	}
	return SubmitOtp200JSONResponse{Success: Ptr(true)}, nil
}

func (Server) CreateBringInRequest(ctx context.Context, request CreateBringInRequestRequestObject) (CreateBringInRequestResponseObject, error) {
	ssoClient := ctx.Value("ssoClient").(*sso.Client)
	client := sre.NewClient(ssoClient)
	for _, path := range *request.Body.FilePaths {
		f, err := os.OpenFile(path, os.O_RDONLY|os.O_CREATE, 0666)
		if err != nil {
			return nil, err
		}
		filePath := filepath.Base(path)
		if err := client.UploadSreFile(filePath, f); err != nil {
			return CreateBringInRequest400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to upload file: %s: %s", path, err))}}, nil
		}
	}
	result, err := client.SubmitBringInRequest(*request.Body.Description)
	if err != nil {
		return CreateBringInRequest400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to submit bring in request %s", err))}}, nil
	}
	return CreateBringInRequest200JSONResponse{
		Id: Ptr(result.ID),
	}, nil
}

func (Server) ListBringInRequest(ctx context.Context, request ListBringInRequestRequestObject) (ListBringInRequestResponseObject, error) {
	ssoClient := ctx.Value("ssoClient").(*sso.Client)
	client := sre.NewClient(ssoClient)
	result, err := client.ListBringInRequest()
	if err != nil {
		return ListBringInRequest400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to list bring in request: %s", err))}}, nil
	}
	var rows ListBringInRequest200JSONResponse
	for _, result := range result {
		rows = append(rows, ListBringInRequestResultRow{
			Description:       Ptr(result.Description),
			DisplayName:       Ptr(result.DisplayName),
			Email:             Ptr(result.Email),
			Id:                Ptr(result.ID),
			InfectedFileCount: Ptr(float32(result.InfectedFileCount)),
			Path:              Ptr(result.Path),
			RequestTime:       Ptr(result.RequestTime),
			SupervisorName:    Ptr(result.SupervisorName),
			TeamName:          Ptr(result.TeamName),
			UserName:          Ptr(result.UserName),
		})
	}
	return rows, nil
}

func (Server) PatchBringInRequest(ctx context.Context, request PatchBringInRequestRequestObject) (PatchBringInRequestResponseObject, error) {
	ssoClient := ctx.Value("ssoClient").(*sso.Client)
	client := sre.NewClient(ssoClient)
	result, err := client.ListBringInRequest()
	if err != nil {
		return PatchBringInRequest400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to list bring in request: %s", err))}}, nil
	}
	for _, result := range result {
		if result.ID == *request.Body.Id {
			if err := client.Proceed(&result, sre.BringInRequestAction(*request.Body.Action), *request.Body.Reason); err != nil {
				return PatchBringInRequest400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr(fmt.Sprintf("failed to perform action on request: %s", err))}}, nil
			}
			return PatchBringInRequest200JSONResponse{Id: Ptr(result.ID), Success: Ptr(true)}, nil
		}
	}
	return PatchBringInRequest404JSONResponse{Detail: Ptr(fmt.Sprintf("failed to find request id %s", *request.Body.Id))}, nil
}

func (Server) SayHello(ctx context.Context, request SayHelloRequestObject) (SayHelloResponseObject, error) {
	return SayHello200JSONResponse{Name: "Angus", Words: nil}, nil
}

type UndiagnosedIsCheckeds struct {
	IsCheckeds      map[string]interface{} `json:"isCheckeds"`
	ExtraHpo        map[string]interface{} `json:"extraHpo"`
	Notes           map[string]interface{} `json:"notes"`
	ClinicalSummary *string                `json:"clinicalSummary"`
}

func extractHPO(u UndiagnosedIsCheckeds) []string {
	result := map[string]struct{}{}
	reg := regexp.MustCompile(`HP:\d{7}`)

	// isCheckeds
	for k, v := range u.IsCheckeds {
		if b, ok := v.(bool); ok && b {
			matches := reg.FindAllString(k, -1)
			for _, hpo := range matches {
				result[hpo] = struct{}{}
			}
		}
	}
	// extraHpo
	for k, v := range u.ExtraHpo {
		if b, ok := v.(bool); ok && b {
			matches := reg.FindAllString(k, -1)
			for _, hpo := range matches {
				result[hpo] = struct{}{}
			}
		}
	}
	out := []string{}
	for hpo := range result {
		out = append(out, hpo)
	}
	return out
}

func extractInvestigation(u UndiagnosedIsCheckeds) ([]string, map[string]string) {
	investigationTest := []string{}
	investigationTestNote := make(map[string]string)

	// Extract from isCheckeds
	for k, v := range u.IsCheckeds {
		if b, ok := v.(bool); ok && b {
			// Check if it's a Previous investigation result
			if strings.Contains(k, "Previous investigation results|") {
				parts := strings.Split(k, "|")
				if len(parts) >= 3 {
					category := parts[1] // e.g., "PREVIOUS GENETIC AND GENOMIC TESTING"
					test := parts[2]     // e.g., "Chromosomes/FISH"

					// Add test to investigationTest if it's PREVIOUS GENETIC AND GENOMIC TESTING
					if category == "PREVIOUS GENETIC AND GENOMIC TESTING" {
						investigationTest = append(investigationTest, test)
					}

					// Look for corresponding note
					noteKey := fmt.Sprintf("Previous investigation results|%s|%s", category, test)
					if noteValue, exists := u.Notes[noteKey]; exists {
						if noteStr, ok := noteValue.(string); ok && noteStr != "" {
							investigationTestNote[test] = noteStr
						}
					}
				}
			}
		}
	}

	// Extract detailed notes for OTHER INVESTIGATION RESULTS (only for investigationTestNote)
	for k, v := range u.Notes {
		if str, ok := v.(string); ok && str != "" {
			// Check if it's an OTHER INVESTIGATION RESULTS note
			if strings.Contains(k, "Previous investigation results|OTHER INVESTIGATION RESULTS|") {
				parts := strings.Split(k, "|")
				if len(parts) >= 3 {
					testName := parts[2] // e.g., "Research testing"
					investigationTestNote[testName] = str
				}
			}
		}
	}

	return investigationTest, investigationTestNote
}

type PatientSummaryResponse struct {
	Patient PatientResponse `json:"patient"`
}

type PatientResponse struct {
	Patient
	HkgiID string `json:"hkgi_id"`
	PcID   string `json:"pc_id"`
}

type SpecimenModified struct {
	Specimen
	LabId              string `json:"lab_id"`
	CollectionDateTime int64  `json:"collectionDateTime"`
}

type SpecimenResponse struct {
	Speciments []SpecimenModified `json:"specimens"`
}

func (s Server) Patient(ctx context.Context, request PatientRequestObject) (PatientResponseObject, error) {

	client, err := s.GetClient(ctx, ClinicalFrontend, Staging)
	if err != nil {
		return Patient400JSONResponse{DefaultErrorJSONResponse{Detail: Ptr("failed to login__")}}, nil
	}

	//Test case1: "e38f016f-53b4-4587-a9c7-8621d9b879a9"
	//Test case2: "67db5677-581b-45ab-82c7-d198f24edaaf"

	patientResp, err := client.Get(fmt.Sprintf("https://app.api.cf-stg.genomeproject.hk/patient/get?id=%s", request.Uid))
	if err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("request failed: " + err.Error())},
		}, nil
	}
	defer patientResp.Body.Close()

	var patientSummary PatientSummaryResponse

	if err := json.NewDecoder(patientResp.Body).Decode(&patientSummary); err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("failed to decode basic information: " + err.Error())},
		}, nil
	}

	patientInfo := patientSummary.Patient

	// Undiagnosed stage

	undiagnosedResp, err := client.Get(fmt.Sprintf("https://app.api.cf-stg.genomeproject.hk/undiagnosed/get?id=%s", request.Uid))
	if err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("request undiagnosed data failed: " + err.Error())},
		}, nil
	}
	defer undiagnosedResp.Body.Close()

	var hpoResult struct {
		Undiagnosed UndiagnosedIsCheckeds `json:"undiagnosed"`
	}

	if err := json.NewDecoder(undiagnosedResp.Body).Decode(&hpoResult); err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("failed to decode undiagnosed : " + err.Error())},
		}, nil
	}

	// Regex function all HPO
	hpoList := extractHPO(hpoResult.Undiagnosed)

	// Extract investigation data
	investigationTest, investigationTestNoteMap := extractInvestigation(hpoResult.Undiagnosed)

	// Convert investigationTestNote map to array of objects
	var investigationTestNote []InvestigationTestNote
	for k, v := range investigationTestNoteMap {
		investigationTestNote = append(investigationTestNote, InvestigationTestNote{
			Entry: k,
			Notes: v,
		})
	}

	// Clincial note
	clinicalNoteResp, err := client.Get(fmt.Sprintf("https://app.api.cf-stg.genomeproject.hk/clinical-note/list?pc_id=%s", patientInfo.PcID))
	if err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("request clincial note failed: " + err.Error())},
		}, nil
	}
	defer clinicalNoteResp.Body.Close()

	var notes []ClinicalNote

	if err := json.NewDecoder(clinicalNoteResp.Body).Decode(&notes); err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("failed to decode clinical notes: " + err.Error())},
		}, nil
	}

	// Specimen
	specimenResp, err := client.Get(fmt.Sprintf("https://app.api.cf-stg.genomeproject.hk/specimen/list?id=%s", request.Uid))
	if err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("request specimen failed: " + err.Error())},
		}, nil
	}
	defer specimenResp.Body.Close()

	var sp SpecimenResponse
	if err := json.NewDecoder(specimenResp.Body).Decode(&sp); err != nil {
		return Patient400JSONResponse{
			DefaultErrorJSONResponse{Detail: Ptr("failed to decode specimen: " + err.Error())},
		}, nil
	}
	specimenResult := make([]Specimen, len(sp.Speciments))
	for i, specimen := range sp.Speciments {
		specimenResult[i] = Specimen{
			Nature:             specimen.Nature,
			LabId:              specimen.LabId,
			CollectionDateTime: time.Unix(specimen.CollectionDateTime, 0),
			Id:                 specimen.Id,
		}
	}

	// // Cancer
	// ref6, err := client.Get(fmt.Sprintf("https://app.api.cf-stg.genomeproject.hk/cancer/get?id=%s", request.Uid))
	// if err != nil {
	// 	return Patient400JSONResponse{
	// 		DefaultErrorJSONResponse{Detail: Ptr("request cancer failed: " + err.Error())},
	// 	}, nil
	// }
	// defer ref6.Body.Close()

	// var cancerResult struct {
	// 	CancerDetails []struct {
	// 		DiseaseSite string `json:"diseaseSite"`
	// 	} `json:"cancerDetails"`
	// }

	// if err := json.NewDecoder(ref6.Body).Decode(&cancerResult); err != nil {
	// 	return Patient400JSONResponse{
	// 		DefaultErrorJSONResponse{Detail: Ptr("failed to decode cancer: " + err.Error())},
	// 	}, nil
	// }

	// // Extract diseaseSite from cancer details
	// var cancerSite *string
	// for _, cancer := range cancerResult.CancerDetails {
	// 	if cancer.DiseaseSite != "" {
	// 		cancerSite = &cancer.DiseaseSite
	// 		break
	// 	}
	// }

	// Return response
	return Patient200JSONResponse{
		HkgiID:                patientInfo.HkgiID,
		PcID:                  patientInfo.PcID,
		Sex:                   patientInfo.Sex,
		BirthDate:             patientInfo.BirthDate,
		ReferDepartment:       patientInfo.ReferDepartment,
		ReferDivision:         patientInfo.ReferDivision,
		AlcoholFrequency:      patientInfo.AlcoholFrequency,
		SmokingStatus:         patientInfo.SmokingStatus,
		HpoTerm:               hpoList,
		ClinicalNote:          notes,
		ClinicalSummary:       hpoResult.Undiagnosed.ClinicalSummary,
		InvestigationTest:     investigationTest,
		Specimen:              specimenResult,
		InvestigationTestNote: investigationTestNote,
		// Cancer:                cancerSite,
	}, nil
}

var clientCache *ttlcache.Cache[ClientKey, *sso.Client]

func NewGinRouter() (*gin.Engine, error) {
	clientCache = ttlcache.New(
		ttlcache.WithTTL[ClientKey, *sso.Client](10 * time.Minute),
	)
	go clientCache.Start()

	server := NewServer()
	router := gin.Default()
	if gin.IsDebugging() {
		router.Use(cors.New(cors.Config{
			AllowAllOrigins:  true,
			AllowMethods:     []string{},
			AllowHeaders:     []string{},
			ExposeHeaders:    []string{},
			AllowCredentials: true,
			MaxAge:           12 * time.Hour,
		}))
	}

	RegisterHandlers(
		router.Group("/", BasicAuthMiddleware()),
		// router.Group("/"),
		NewStrictHandler(server, nil),
	)
	spec, err := GetSwagger()
	if err != nil {
		return nil, fmt.Errorf("failed to load openapi spec: %w", err)
	}
	router.GET("/openapi.json", func(c *gin.Context) {
		c.JSON(http.StatusOK, spec)
	})

	router.StaticFileFS("/docs", "public/swagger.html", http.FS(staticFiles))
	return router, nil
}

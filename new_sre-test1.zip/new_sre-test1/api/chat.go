package api

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/sashabaranov/go-openai"
)

// ChatRequest 聊天請求結構
type ChatRequest struct {
	Message   string  `json:"message"`
	SessionID *string `json:"sessionId,omitempty"`
	ServerURL *string `json:"serverUrl,omitempty"`
}

// ChatResponse 聊天響應結構
type ChatResponse struct {
	Response     string  `json:"response"`
	UsedFunction *bool   `json:"usedFunction,omitempty"`
	FunctionName *string `json:"functionName,omitempty"`
	SessionID    *string `json:"sessionId,omitempty"`
	Timestamp    string  `json:"timestamp"`
}

// ChatSession 聊天會話結構
type ChatSession struct {
	ID        string    `json:"id"`
	UserID    string    `json:"userId"`
	Messages  []Message `json:"messages"`
	CreatedAt time.Time `json:"createdAt"`
	UpdatedAt time.Time `json:"updatedAt"`
}

// Message 消息結構
type Message struct {
	Role      string    `json:"role"`
	Content   string    `json:"content"`
	Timestamp time.Time `json:"timestamp"`
}

// ErrorResponse 錯誤響應結構
type ErrorResponse struct {
	Error string `json:"error"`
}

// ChatService 聊天服務
type ChatService struct {
	openaiClient *openai.Client
	sessions     map[string]*ChatSession
}

// NewChatService 創建新的聊天服務
func NewChatService(apiKey, baseURL string) *ChatService {
	config := openai.DefaultConfig(apiKey)
	config.BaseURL = baseURL

	return &ChatService{
		openaiClient: openai.NewClientWithConfig(config),
		sessions:     make(map[string]*ChatSession),
	}
}

// chatWithFunctionCall 使用函數調用的聊天功能
func (cs *ChatService) chatWithFunctionCall(userMessage string, serverURL string, c *gin.Context) (string, bool, string, error) {
	// 定義工具
	tools := []openai.Tool{
		{
			Type: "function",
			Function: &openai.FunctionDefinition{
				Name:        "get_patient_info",
				Description: "Return the patient information from clinical frontend",
				Parameters: map[string]interface{}{
					"type": "object",
					"properties": map[string]interface{}{
						"UID": map[string]interface{}{
							"type":        "string",
							"description": "With the patient UID , follow the user question to analyze the patient condition",
						},
					},
					"required": []string{"UID"},
				},
			},
		},
	}

	// 創建消息
	messages := []openai.ChatCompletionMessage{
		{
			Role:    openai.ChatMessageRoleUser,
			Content: userMessage,
		},
	}

	ctx := context.Background()

	// 第一次調用
	req := openai.ChatCompletionRequest{
		Model:       "Qwen/Qwen3-235B-A22B-MLX-8bit",
		Messages:    messages,
		Temperature: 0.1,
		TopP:        0.15,
		Tools:       tools,
		ToolChoice:  "auto",
	}

	resp, err := cs.openaiClient.CreateChatCompletion(ctx, req)
	if err != nil {
		return "", false, "", fmt.Errorf("error in first API call: %v", err)
	}

	message := resp.Choices[0].Message
	usedFunction := false
	functionName := ""

	// 如果有函數調用，處理它
	if len(message.ToolCalls) > 0 {
		usedFunction = true
		for _, toolCall := range message.ToolCalls {
			functionName = toolCall.Function.Name
			var functionArgs map[string]interface{}

			if err := json.Unmarshal([]byte(toolCall.Function.Arguments), &functionArgs); err != nil {
				return "", false, "", fmt.Errorf("error parsing function arguments: %v", err)
			}

			var functionResult interface{}

			if functionName == "get_patient_info" {
				if UID, ok := functionArgs["UID"].(string); ok {
					functionResult = cs.getPatientInfo(UID, serverURL, getCredentialFromContext(c))
				} else {
					functionResult = ErrorResponse{Error: "UID parameter is required"}
				}
			} else {
				functionResult = ErrorResponse{Error: fmt.Sprintf("unknown function: %s", functionName)}
			}

			// 將函數結果轉換為 JSON 字符串
			resultJSON, err := json.Marshal(functionResult)
			if err != nil {
				return "", false, "", fmt.Errorf("error marshaling function result: %v", err)
			}

			// 添加函數結果到消息
			messages = append(messages, openai.ChatCompletionMessage{
				Role:       openai.ChatMessageRoleTool,
				ToolCallID: toolCall.ID,
				Content:    string(resultJSON),
			})
		}

		// 第二次調用，讓 AI 基於函數結果回應
		req2 := openai.ChatCompletionRequest{
			Model:       "Qwen/Qwen3-235B-A22B-MLX-8bit",
			Messages:    messages,
			Temperature: 0.1,
			Tools:       tools,
			ToolChoice:  "none", // 不再調用函數
		}

		resp2, err := cs.openaiClient.CreateChatCompletion(ctx, req2)
		if err != nil {
			return "", false, "", fmt.Errorf("error in second API call: %v", err)
		}

		return resp2.Choices[0].Message.Content, usedFunction, functionName, nil
	} else {
		// 如果沒有函數調用，返回響應
		return message.Content, usedFunction, functionName, nil
	}
}

// getPatientInfo 獲取患者信息
func (cs *ChatService) getPatientInfo(UID string, serverURL string, credential Credential) interface{} {
	url := fmt.Sprintf("%s/patient/%s", serverURL, UID)

	// 創建 HTTP 請求
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("Error creating request: %v", err)}
	}

	// 設置基本認證
	req.SetBasicAuth(credential.Name, credential.Password)

	// 發送請求
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("Error sending request: %v", err)}
	}
	defer resp.Body.Close()

	// 檢查響應狀態
	if resp.StatusCode != http.StatusOK {
		return ErrorResponse{Error: fmt.Sprintf("HTTP error: %d", resp.StatusCode)}
	}

	// 讀取響應內容
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return ErrorResponse{Error: fmt.Sprintf("Error reading response: %v", err)}
	}

	// 解析 JSON 響應
	var patientInfo Patient
	if err := json.Unmarshal(body, &patientInfo); err != nil {
		return ErrorResponse{Error: fmt.Sprintf("Error parsing JSON: %v", err)}
	}

	return patientInfo
}

// RegisterChatRoutes 註冊聊天相關的路由
func (cs *ChatService) RegisterChatRoutes(router *gin.Engine) {
	// 使用基本認證中間件來保護聊天路由
	chatGroup := router.Group("/api/chat", BasicAuthMiddleware())
	{
		chatGroup.POST("/", cs.HandleChat)
		chatGroup.POST("/session", cs.CreateSession)
		chatGroup.GET("/session/:sessionId", cs.GetSession)
		chatGroup.GET("/session/:sessionId/history", cs.GetChatHistory)
	}
}

// HandleChat 處理聊天請求
func (cs *ChatService) HandleChat(c *gin.Context) {
	var req ChatRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// 設置默認服務器 URL
	serverURL := "http://localhost:8080"
	if req.ServerURL != nil && *req.ServerURL != "" {
		serverURL = *req.ServerURL
	}

	// 記錄請求
	log.Printf("Chat request from user: %s, message: %s, server: %s", getUsernameFromContext(c), req.Message, serverURL)

	start := time.Now()

	// 調用聊天功能
	response, usedFunction, functionName, err := cs.chatWithFunctionCall(req.Message, serverURL, c)
	if err != nil {
		log.Printf("Chat error: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// 創建響應
	chatResponse := ChatResponse{
		Response:     response,
		UsedFunction: &usedFunction,
		Timestamp:    time.Now().Format(time.RFC3339),
	}

	if usedFunction {
		chatResponse.FunctionName = &functionName
	}

	if req.SessionID != nil {
		chatResponse.SessionID = req.SessionID
		// 保存到會話
		cs.saveToSession(*req.SessionID, req.Message, response)
	}

	// 記錄響應時間
	log.Printf("Chat completed in %v", time.Since(start))

	c.JSON(http.StatusOK, chatResponse)
}

// CreateSession 創建新的聊天會話
func (cs *ChatService) CreateSession(c *gin.Context) {
	userID := getUsernameFromContext(c)
	sessionID := generateSessionID()

	session := &ChatSession{
		ID:        sessionID,
		UserID:    userID,
		Messages:  []Message{},
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	cs.sessions[sessionID] = session

	c.JSON(http.StatusOK, gin.H{
		"sessionId": sessionID,
		"message":   "Session created successfully",
	})
}

// GetSession 獲取會話信息
func (cs *ChatService) GetSession(c *gin.Context) {
	sessionID := c.Param("sessionId")

	session, exists := cs.sessions[sessionID]
	if !exists {
		c.JSON(http.StatusNotFound, gin.H{"error": "Session not found"})
		return
	}

	c.JSON(http.StatusOK, session)
}

// GetChatHistory 獲取聊天歷史
func (cs *ChatService) GetChatHistory(c *gin.Context) {
	sessionID := c.Param("sessionId")

	session, exists := cs.sessions[sessionID]
	if !exists {
		c.JSON(http.StatusNotFound, gin.H{"error": "Session not found"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"sessionId": sessionID,
		"messages":  session.Messages,
	})
}

// saveToSession 保存消息到會話
func (cs *ChatService) saveToSession(sessionID, userMessage, aiResponse string) {
	session, exists := cs.sessions[sessionID]
	if !exists {
		return
	}

	now := time.Now()

	// 添加用戶消息
	session.Messages = append(session.Messages, Message{
		Role:      "user",
		Content:   userMessage,
		Timestamp: now,
	})

	// 添加 AI 響應
	session.Messages = append(session.Messages, Message{
		Role:      "assistant",
		Content:   aiResponse,
		Timestamp: now,
	})

	session.UpdatedAt = now
}

// 輔助函數
func getUsernameFromContext(c *gin.Context) string {
	if credential, exists := c.Get("credential"); exists {
		if cred, ok := credential.(Credential); ok {
			return cred.Name
		}
	}
	return "unknown"
}

func getCredentialFromContext(c *gin.Context) Credential {
	if credential, exists := c.Get("credential"); exists {
		if cred, ok := credential.(Credential); ok {
			return cred
		}
	}
	return Credential{Name: "unknown", Password: ""}
}

func generateSessionID() string {
	return fmt.Sprintf("session_%d", time.Now().UnixNano())
}

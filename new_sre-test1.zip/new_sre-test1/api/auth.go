package api

import (
	"context"
	"encoding/base64"
	"fmt"
	"net/http"
	"sre-transfer/sso"
	"strings"
	"time"

	"github.com/rs/zerolog/log"

	"github.com/gin-gonic/gin"
)

type Credential struct {
	Name     string
	Password string
}

type ClientKey struct {
	Name        string
	Application sso.Application
	Env         sso.Environment
}

const Salt = "QD1oqzvb7j"

func BasicAuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		// Get the Authorization header
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.Header("WWW-Authenticate", `Basic realm="Restricted"`)
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "authorization header required"})
			return
		}

		// Check if the header starts with "Basic "
		if !strings.HasPrefix(authHeader, "Basic ") {
			c.Header("WWW-Authenticate", `Basic realm="Restricted"`)
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid authorization header"})
			return
		}

		// Decode the Base64-encoded credentials
		encodedCredentials := strings.TrimPrefix(authHeader, "Basic ")
		decodedCredentials, err := base64.StdEncoding.DecodeString(encodedCredentials)
		if err != nil {
			c.Header("WWW-Authenticate", `Basic realm="Restricted"`)
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid Base64 encoding"})
			return
		}

		// Split the credentials into username and password
		credentials := strings.SplitN(string(decodedCredentials), ":", 2)
		if len(credentials) != 2 {
			c.Header("WWW-Authenticate", `Basic realm="Restricted"`)
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "invalid credentials format"})
			return
		}
		var username, password = credentials[0], credentials[1]

		c.Set("credential", Credential{Name: username, Password: password})

		// Credentials are valid, proceed with the request
		c.Next()
	}
}

func (s Server) GetClient(ctx context.Context, application Application, env Environment) (*sso.Client, error) {
	var client *sso.Client
	ginCtx, ok := ctx.(*gin.Context)
	if !ok {
		return nil, fmt.Errorf("failed to cast the context to a *gin.Context")
	}
	credentialValue, ok := ginCtx.Get("credential")
	if !ok {
		return nil, fmt.Errorf("failed to get credential from gin context, possibly unauthorized")
	}
	credential, ok := credentialValue.(Credential)
	if !ok {
		return nil, fmt.Errorf("the context credential is not a credential")
	}

	appMap := map[Application]sso.Application{
		Sre:              sso.Sre,
		ClinicalFrontend: sso.ClinicalFrontend,
	}

	envMap := map[Environment]sso.Environment{
		Staging:       sso.Staging,
		Preproduction: sso.Preproduction,
		Production:    sso.Production,
	}

	clientKey := ClientKey{Name: credential.Name, Application: appMap[application], Env: envMap[env]}
	clientItem := clientCache.Get(clientKey)
	if clientItem != nil {
		log.Debug().Msg("client found, skip login")
		client = clientItem.Value()
	} else {
		log.Debug().Str("application", appMap[application]).Str("environment", string(envMap[env])).Msg("client not found, logging in")
		newClient, err := sso.NewClient(appMap[application], envMap[env], credential.Name, credential.Password)
		if err != nil {
			return nil, fmt.Errorf("failed to login, %w", err)
		}
		clientCache.Set(clientKey, newClient, 10*time.Minute)
		client = newClient
	}
	return client, nil
}

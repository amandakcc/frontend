import uvicorn
uvicorn.run(
        "mlx_omni_server.main:app",
        host='0.0.0.0',
        port=8080,
        log_level='DEBUG',
        use_colors=True,
        workers=4,
        ssl_certfile='/home/athho/cert.pem',
        ssl_keyfile='/home/athho/key.pem',
    )